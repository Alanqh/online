
export enum BehaviorRet {
    Fail = 0,
    Success,
    Running,
}

export enum BehaviorType {
    Composite = "Composite",
    Decorator = "Decorator",
    Condition = "Condition",
    Action = "Action"
}
