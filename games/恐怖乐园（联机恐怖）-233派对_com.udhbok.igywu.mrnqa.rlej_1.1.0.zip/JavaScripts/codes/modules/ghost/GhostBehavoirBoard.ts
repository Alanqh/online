export class GhostBehavoirBoard {
    public hateArr: number[] = [];
}