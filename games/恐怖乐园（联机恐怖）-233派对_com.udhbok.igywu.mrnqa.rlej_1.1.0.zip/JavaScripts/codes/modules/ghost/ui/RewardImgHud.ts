import Animation2D_Generate from "../../../../ui-generate/ShareUI/Animation2D_generate";

export default class RewardImgHud extends Animation2D_Generate {
}