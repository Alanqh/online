import { IslandGhostModuleS } from "./IslandGhostModuleS";

export class IslandGhostModuleC extends ModuleC<IslandGhostModuleS, null> {

}