export enum FrameType {
    Camera,
    Events,
    UpdateEvents
}