﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 冰玥
 * UI: UI/BubbleUI.ui
 * TIME: 2023.06.26-15.01.49
*/



@UIBind('UI/BubbleUI.ui')
export default class BubbleUI_Generate extends mw.UIScript {
	@UIWidgetBind('MWCanvas_2147482460/dialogBg1')
    public dialogBg1: mw.Image=undefined;
    @UIWidgetBind('MWCanvas_2147482460/dialogBg')
    public dialogBg: mw.Image=undefined;
    @UIWidgetBind('MWCanvas_2147482460/dialogText')
    public dialogText: mw.TextBlock=undefined;
    

 
	/**
	* onStart 之前触发一次
	*/
	protected onAwake() {
	}
	 
}
 