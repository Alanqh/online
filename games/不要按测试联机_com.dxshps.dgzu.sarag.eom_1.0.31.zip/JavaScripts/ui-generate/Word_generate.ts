﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 冰玥
 * UI: UI/Word.ui
 * TIME: 2023.06.26-15.01.49
*/



@UIBind('UI/Word.ui')
export default class Word_Generate extends mw.UIScript {
	@UIWidgetBind('Canvas/mBtn_word')
    public mBtn_word: mw.StaleButton=undefined;
    

 
	/**
	* onStart 之前触发一次
	*/
	protected onAwake() {
	}
	 
}
 