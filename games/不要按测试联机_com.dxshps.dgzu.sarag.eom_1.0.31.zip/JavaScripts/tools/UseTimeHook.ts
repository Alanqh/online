// //aits-ignore
// export class UseTimeHook {

//     public static run(func: () => void) {
//         let start = Date.now();
//         func();
//         let end = Date.now();
//         console.log("use time : " + (end - start) + " ms");
//     }

// }