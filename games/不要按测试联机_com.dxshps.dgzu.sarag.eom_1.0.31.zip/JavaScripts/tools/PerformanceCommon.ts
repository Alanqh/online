// //aits-ignore
// /*
//  * @Author: YuKun.Gao
//  * @Date: 2023-08-09 18:26:10
//  * @LastEditors: YuKun.Gao
//  * @LastEditTime: 2023-08-09 18:26:35
//  * @Description: file content
//  * @FilePath: \Ecs\JavaScripts\PerformanceUtils\PerformanceCommon.ts
//  */

// export class PerformanceCommon {

//     public static timeUnix: number = 0;

// }