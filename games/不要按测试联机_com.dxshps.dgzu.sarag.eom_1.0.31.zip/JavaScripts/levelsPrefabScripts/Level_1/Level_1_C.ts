﻿import { LevelLogic_C } from "../LevelLogic_C";
import Level_1 from "./Level_1";


export class Level_1_C extends LevelLogic_C<Level_1> {
    protected onInitClient() {
        // throw new Error("Method not implemented.");
    }

}
