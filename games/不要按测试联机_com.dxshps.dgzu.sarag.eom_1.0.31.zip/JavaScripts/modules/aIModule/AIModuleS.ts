import { AIModuleC } from "./AIModuleC";


export class AIModuleS extends ModuleS<AIModuleC, null>{
    //TODO:可能双端AI？？？
}