﻿import { BaseState } from "../../../fsm/StateMachine";


export class DeathState extends BaseState {
    init(cfgId: number): void {
    }
    enter(...param: any[]): void {
    }
    update(dt: number): void {
    }
    exit(): void {
    }


}