export class RankData {
    /**
     * 玩家ID,去重
     */
    userId: string;
    /**
     * 玩家名称
     */
    name: string;
    /**
     * 玩家数据
     */
    data: number;
}