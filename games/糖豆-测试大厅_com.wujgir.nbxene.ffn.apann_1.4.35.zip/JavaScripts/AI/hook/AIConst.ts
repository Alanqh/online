export namespace AIConst {
    export const TEMP_VEC = new mw.Vector();
    export const TEMP_VEC_1 = new mw.Vector();
    export let gravityScale = 1;
    export let roundWalkTime = 0;
    export let roundWalkInterval = 0;
}