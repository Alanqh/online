import { GameConfig } from "../config/GameConfig";

export namespace GameCamera {
    export function setCameraParam(camera: Camera) {
        // const trans = Transform.identity;
        // const cfg = GameConfig.CameraConfig.getElement(1);
        // trans.position = cfg.cameraRelativeLocation;
        // trans.rotation.set(cfg.cameraRelativeRotation.x, cfg.cameraRelativeRotation.y, cfg.cameraRelativeRotation.z);
        // camera.localTransform = trans;

        // camera.fov = cfg.fov;
        // camera.springArm.collisionEnabled = cfg.isCameraCollision;
        // camera.springArm.length = cfg.springArmLength;


        // camera.upAngleLimit = cfg.upAngleLimit;
        // camera.downAngleLimit = cfg.downAngleLimit;

        // camera.fadeObstructionEnabled = cfg.isObjectTransparent;
        // camera.fadeObstructionOpacity = cfg.transparency;

        // let armTrans = camera.springArm.localTransform;
        // armTrans.position.set(0, 0, 30);
        // camera.springArm.localTransform = armTrans;
        // camera.positionLagEnabled = cfg.isCameraPositionDelay;
        // camera.positionLagSpeed = cfg.positionDelaySpeed;
        // camera.rotationLagSpeed = cfg.rotationDelaySpeed;
        // const rotation = Player.getControllerRotation();
        // rotation.y = -30;
        // Player.setControllerRotation(rotation);

    }
}