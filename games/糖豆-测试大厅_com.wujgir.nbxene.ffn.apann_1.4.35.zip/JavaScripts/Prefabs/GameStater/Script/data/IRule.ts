export interface ITeamRule {
    onUpdate(dt: number);
    onStop();
}