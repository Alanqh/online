﻿import TangentialScriptBase from "../../../newPrefab/TangentialScript";

@Component
export default class TangentialScript extends TangentialScriptBase {

}