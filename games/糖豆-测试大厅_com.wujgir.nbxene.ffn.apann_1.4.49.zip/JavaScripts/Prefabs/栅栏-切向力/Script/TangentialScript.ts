﻿/** 
 * @Author       : yuanqi.bai
 * @Date         : 2023-02-02 18:50:55
 * @LastEditors  : lei.zhao
 * @LastEditTime : 2023-06-07 18:03:55
 * @FilePath     : \stumbleguys\JavaScripts\Prefabs\栅栏-切向力\Script\TangentialScript.ts
 * @Description  : 切向力
 */
import TangentialScriptBase from "../../../newPrefab/TangentialScript";

@Component
export default class TangentialScript extends TangentialScriptBase {

}