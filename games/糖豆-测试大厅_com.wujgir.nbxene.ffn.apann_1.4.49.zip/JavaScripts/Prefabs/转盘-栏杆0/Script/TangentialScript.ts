﻿/** 
 * @Author       : yuanqi.bai
 * @Date         : 2023-06-06 11:08:19
 * @LastEditors  : yuanqi.bai
 * @LastEditTime : 2023-06-06 11:28:55
 * @FilePath     : \stumbleguys\JavaScripts\Prefabs\转盘-栏杆0\Script\TangentialScript.ts
 * @Description  : 修改描述
 */
import TangentialScriptBase from "../../../newPrefab/TangentialScript";

@Component
export default class TangentialScript extends TangentialScriptBase {

}