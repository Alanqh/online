﻿/** 
 * @Author       : zhenhaung.luo  zhenhuang.luo@appshahe.com
 * @Date         : 2023-03-02 13:25:03
 * @LastEditors  : haitao.zhong
 * @LastEditTime : 2023-05-14 14:59:16
 * @FilePath     : \stumbleguys\JavaScripts\modules\dress\Enums.ts
 * @Descripttion : 
 */
export namespace Enums {
    export enum EquipDressType {
        skin = 1,
        emotes = 2,
        anim = 3,
        foot = 4,
        hand = 5,
        back = 6
    }

}