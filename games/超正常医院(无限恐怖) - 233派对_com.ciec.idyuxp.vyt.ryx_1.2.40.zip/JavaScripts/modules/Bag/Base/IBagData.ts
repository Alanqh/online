﻿

export default class IBagData  {

    /**背包物品唯一标识 */
    key: number;
}