﻿import PropItem_Generate from "../../ui-generate/Porp/PropItem_generate";

export default class P_PropItem extends PropItem_Generate {

    
}