﻿import { SportModuleC } from "./SportModuleC";

/**
 * 玩家运动模块
 */
export class SportModuleS extends ModuleS<SportModuleC, null> {
    
}