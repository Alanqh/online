﻿
export default class DeadCountModuleData extends Subdata {

    

}