﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 */



@UIBind('UI/Lottery/LotteryWindow.ui')
export default class LotteryWindow_Generate extends UIScript {
		private img_bg_Internal: mw.Image
	public get img_bg(): mw.Image {
		if(!this.img_bg_Internal&&this.uiWidgetBase) {
			this.img_bg_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/img_bg') as mw.Image
		}
		return this.img_bg_Internal
	}
	private img_bg1_Internal: mw.Image
	public get img_bg1(): mw.Image {
		if(!this.img_bg1_Internal&&this.uiWidgetBase) {
			this.img_bg1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/img_bg1') as mw.Image
		}
		return this.img_bg1_Internal
	}
	private canvas_normal_Internal: mw.Canvas
	public get canvas_normal(): mw.Canvas {
		if(!this.canvas_normal_Internal&&this.uiWidgetBase) {
			this.canvas_normal_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal') as mw.Canvas
		}
		return this.canvas_normal_Internal
	}
	private img_bg_normal_Internal: mw.Image
	public get img_bg_normal(): mw.Image {
		if(!this.img_bg_normal_Internal&&this.uiWidgetBase) {
			this.img_bg_normal_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/img_bg_normal') as mw.Image
		}
		return this.img_bg_normal_Internal
	}
	private img_bg_normal2_Internal: mw.Image
	public get img_bg_normal2(): mw.Image {
		if(!this.img_bg_normal2_Internal&&this.uiWidgetBase) {
			this.img_bg_normal2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/img_bg_normal2') as mw.Image
		}
		return this.img_bg_normal2_Internal
	}
	private canvas_quest_normal_Internal: mw.Canvas
	public get canvas_quest_normal(): mw.Canvas {
		if(!this.canvas_quest_normal_Internal&&this.uiWidgetBase) {
			this.canvas_quest_normal_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal') as mw.Canvas
		}
		return this.canvas_quest_normal_Internal
	}
	private canvas_quest1_Internal: mw.Canvas
	public get canvas_quest1(): mw.Canvas {
		if(!this.canvas_quest1_Internal&&this.uiWidgetBase) {
			this.canvas_quest1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest1') as mw.Canvas
		}
		return this.canvas_quest1_Internal
	}
	private img_quest1_bg_Internal: mw.Image
	public get img_quest1_bg(): mw.Image {
		if(!this.img_quest1_bg_Internal&&this.uiWidgetBase) {
			this.img_quest1_bg_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest1/img_quest1_bg') as mw.Image
		}
		return this.img_quest1_bg_Internal
	}
	private btn_quest1_Internal: mw.Button
	public get btn_quest1(): mw.Button {
		if(!this.btn_quest1_Internal&&this.uiWidgetBase) {
			this.btn_quest1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest1/btn_quest1') as mw.Button
		}
		return this.btn_quest1_Internal
	}
	private txt_prices1_Internal: mw.TextBlock
	public get txt_prices1(): mw.TextBlock {
		if(!this.txt_prices1_Internal&&this.uiWidgetBase) {
			this.txt_prices1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest1/txt_prices1') as mw.TextBlock
		}
		return this.txt_prices1_Internal
	}
	private img_quest1_icon_Internal: mw.Image
	public get img_quest1_icon(): mw.Image {
		if(!this.img_quest1_icon_Internal&&this.uiWidgetBase) {
			this.img_quest1_icon_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest1/img_quest1_icon') as mw.Image
		}
		return this.img_quest1_icon_Internal
	}
	private txt_quest1_Internal: mw.TextBlock
	public get txt_quest1(): mw.TextBlock {
		if(!this.txt_quest1_Internal&&this.uiWidgetBase) {
			this.txt_quest1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest1/txt_quest1') as mw.TextBlock
		}
		return this.txt_quest1_Internal
	}
	private canvas_quest2_Internal: mw.Canvas
	public get canvas_quest2(): mw.Canvas {
		if(!this.canvas_quest2_Internal&&this.uiWidgetBase) {
			this.canvas_quest2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest2') as mw.Canvas
		}
		return this.canvas_quest2_Internal
	}
	private img_quest2_bg_Internal: mw.Image
	public get img_quest2_bg(): mw.Image {
		if(!this.img_quest2_bg_Internal&&this.uiWidgetBase) {
			this.img_quest2_bg_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest2/img_quest2_bg') as mw.Image
		}
		return this.img_quest2_bg_Internal
	}
	private btn_quest2_Internal: mw.Button
	public get btn_quest2(): mw.Button {
		if(!this.btn_quest2_Internal&&this.uiWidgetBase) {
			this.btn_quest2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest2/btn_quest2') as mw.Button
		}
		return this.btn_quest2_Internal
	}
	private txt_prices2_Internal: mw.TextBlock
	public get txt_prices2(): mw.TextBlock {
		if(!this.txt_prices2_Internal&&this.uiWidgetBase) {
			this.txt_prices2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest2/txt_prices2') as mw.TextBlock
		}
		return this.txt_prices2_Internal
	}
	private img_quest2_icon_Internal: mw.Image
	public get img_quest2_icon(): mw.Image {
		if(!this.img_quest2_icon_Internal&&this.uiWidgetBase) {
			this.img_quest2_icon_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest2/img_quest2_icon') as mw.Image
		}
		return this.img_quest2_icon_Internal
	}
	private txt_quest2_Internal: mw.TextBlock
	public get txt_quest2(): mw.TextBlock {
		if(!this.txt_quest2_Internal&&this.uiWidgetBase) {
			this.txt_quest2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest2/txt_quest2') as mw.TextBlock
		}
		return this.txt_quest2_Internal
	}
	private canvas_quest3_Internal: mw.Canvas
	public get canvas_quest3(): mw.Canvas {
		if(!this.canvas_quest3_Internal&&this.uiWidgetBase) {
			this.canvas_quest3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest3') as mw.Canvas
		}
		return this.canvas_quest3_Internal
	}
	private img_quest3_bg_Internal: mw.Image
	public get img_quest3_bg(): mw.Image {
		if(!this.img_quest3_bg_Internal&&this.uiWidgetBase) {
			this.img_quest3_bg_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest3/img_quest3_bg') as mw.Image
		}
		return this.img_quest3_bg_Internal
	}
	private btn_quest3_Internal: mw.Button
	public get btn_quest3(): mw.Button {
		if(!this.btn_quest3_Internal&&this.uiWidgetBase) {
			this.btn_quest3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest3/btn_quest3') as mw.Button
		}
		return this.btn_quest3_Internal
	}
	private img_prices3_Internal: mw.Image
	public get img_prices3(): mw.Image {
		if(!this.img_prices3_Internal&&this.uiWidgetBase) {
			this.img_prices3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest3/img_prices3') as mw.Image
		}
		return this.img_prices3_Internal
	}
	private txt_prices3_Internal: mw.TextBlock
	public get txt_prices3(): mw.TextBlock {
		if(!this.txt_prices3_Internal&&this.uiWidgetBase) {
			this.txt_prices3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest3/txt_prices3') as mw.TextBlock
		}
		return this.txt_prices3_Internal
	}
	private img_quest3_icon_Internal: mw.Image
	public get img_quest3_icon(): mw.Image {
		if(!this.img_quest3_icon_Internal&&this.uiWidgetBase) {
			this.img_quest3_icon_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest3/img_quest3_icon') as mw.Image
		}
		return this.img_quest3_icon_Internal
	}
	private txt_quest3_Internal: mw.TextBlock
	public get txt_quest3(): mw.TextBlock {
		if(!this.txt_quest3_Internal&&this.uiWidgetBase) {
			this.txt_quest3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_quest_normal/canvas_quest3/txt_quest3') as mw.TextBlock
		}
		return this.txt_quest3_Internal
	}
	private mCanvas_Goods_Internal: mw.Canvas
	public get mCanvas_Goods(): mw.Canvas {
		if(!this.mCanvas_Goods_Internal&&this.uiWidgetBase) {
			this.mCanvas_Goods_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/mCanvas_Goods') as mw.Canvas
		}
		return this.mCanvas_Goods_Internal
	}
	private mBtn_Open_Internal: mw.Button
	public get mBtn_Open(): mw.Button {
		if(!this.mBtn_Open_Internal&&this.uiWidgetBase) {
			this.mBtn_Open_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/mCanvas_Goods/mBtn_Open') as mw.Button
		}
		return this.mBtn_Open_Internal
	}
	private canvas_GachaTimes_Internal: mw.Canvas
	public get canvas_GachaTimes(): mw.Canvas {
		if(!this.canvas_GachaTimes_Internal&&this.uiWidgetBase) {
			this.canvas_GachaTimes_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_GachaTimes') as mw.Canvas
		}
		return this.canvas_GachaTimes_Internal
	}
	private mTxt_GachaTimes_Internal: mw.TextBlock
	public get mTxt_GachaTimes(): mw.TextBlock {
		if(!this.mTxt_GachaTimes_Internal&&this.uiWidgetBase) {
			this.mTxt_GachaTimes_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_normal/canvas_GachaTimes/mTxt_GachaTimes') as mw.TextBlock
		}
		return this.mTxt_GachaTimes_Internal
	}
	private img_bg_premium2_Internal: mw.Image
	public get img_bg_premium2(): mw.Image {
		if(!this.img_bg_premium2_Internal&&this.uiWidgetBase) {
			this.img_bg_premium2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/img_bg_premium2') as mw.Image
		}
		return this.img_bg_premium2_Internal
	}
	private mBtn_20Times_Internal: mw.StaleButton
	public get mBtn_20Times(): mw.StaleButton {
		if(!this.mBtn_20Times_Internal&&this.uiWidgetBase) {
			this.mBtn_20Times_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas_reward/Canvas_1/mBtn_20Times') as mw.StaleButton
		}
		return this.mBtn_20Times_Internal
	}
	private mBtn_40Times_Internal: mw.StaleButton
	public get mBtn_40Times(): mw.StaleButton {
		if(!this.mBtn_40Times_Internal&&this.uiWidgetBase) {
			this.mBtn_40Times_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas_reward/Canvas_1_1/mBtn_40Times') as mw.StaleButton
		}
		return this.mBtn_40Times_Internal
	}
	private mBtn_60Times_Internal: mw.StaleButton
	public get mBtn_60Times(): mw.StaleButton {
		if(!this.mBtn_60Times_Internal&&this.uiWidgetBase) {
			this.mBtn_60Times_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas_reward/Canvas_1_1_1/mBtn_60Times') as mw.StaleButton
		}
		return this.mBtn_60Times_Internal
	}
	private mBtn_100Times_Internal: mw.StaleButton
	public get mBtn_100Times(): mw.StaleButton {
		if(!this.mBtn_100Times_Internal&&this.uiWidgetBase) {
			this.mBtn_100Times_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas_reward/Canvas_1_1_1_1/mBtn_100Times') as mw.StaleButton
		}
		return this.mBtn_100Times_Internal
	}
	private canvas_Gifts_Internal: mw.Canvas
	public get canvas_Gifts(): mw.Canvas {
		if(!this.canvas_Gifts_Internal&&this.uiWidgetBase) {
			this.canvas_Gifts_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_Gifts') as mw.Canvas
		}
		return this.canvas_Gifts_Internal
	}
	private canvas_GiftsItem_Internal: mw.Canvas
	public get canvas_GiftsItem(): mw.Canvas {
		if(!this.canvas_GiftsItem_Internal&&this.uiWidgetBase) {
			this.canvas_GiftsItem_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_Gifts/canvas_GiftsItem') as mw.Canvas
		}
		return this.canvas_GiftsItem_Internal
	}
	private img_icon24_Internal: mw.Image
	public get img_icon24(): mw.Image {
		if(!this.img_icon24_Internal&&this.uiWidgetBase) {
			this.img_icon24_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_Gifts/canvas_GiftsItem/Canvas/img_icon24') as mw.Image
		}
		return this.img_icon24_Internal
	}
	private img_prices44_Internal: mw.Image
	public get img_prices44(): mw.Image {
		if(!this.img_prices44_Internal&&this.uiWidgetBase) {
			this.img_prices44_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_Gifts/canvas_GiftsItem/Canvas/img_prices44') as mw.Image
		}
		return this.img_prices44_Internal
	}
	private img_icon23_Internal: mw.Image
	public get img_icon23(): mw.Image {
		if(!this.img_icon23_Internal&&this.uiWidgetBase) {
			this.img_icon23_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_Gifts/canvas_GiftsItem/Canvas_1/img_icon23') as mw.Image
		}
		return this.img_icon23_Internal
	}
	private img_prices33_Internal: mw.Image
	public get img_prices33(): mw.Image {
		if(!this.img_prices33_Internal&&this.uiWidgetBase) {
			this.img_prices33_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_Gifts/canvas_GiftsItem/Canvas_1/img_prices33') as mw.Image
		}
		return this.img_prices33_Internal
	}
	private mBtn_Get_Internal: mw.StaleButton
	public get mBtn_Get(): mw.StaleButton {
		if(!this.mBtn_Get_Internal&&this.uiWidgetBase) {
			this.mBtn_Get_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_Gifts/canvas_GiftsItem/mBtn_Get') as mw.StaleButton
		}
		return this.mBtn_Get_Internal
	}
	private canvas_premium_Internal: mw.Canvas
	public get canvas_premium(): mw.Canvas {
		if(!this.canvas_premium_Internal&&this.uiWidgetBase) {
			this.canvas_premium_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium') as mw.Canvas
		}
		return this.canvas_premium_Internal
	}
	private img_bg_premium_Internal: mw.Image
	public get img_bg_premium(): mw.Image {
		if(!this.img_bg_premium_Internal&&this.uiWidgetBase) {
			this.img_bg_premium_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/img_bg_premium') as mw.Image
		}
		return this.img_bg_premium_Internal
	}
	private canvas_quest_premium_Internal: mw.Canvas
	public get canvas_quest_premium(): mw.Canvas {
		if(!this.canvas_quest_premium_Internal&&this.uiWidgetBase) {
			this.canvas_quest_premium_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium') as mw.Canvas
		}
		return this.canvas_quest_premium_Internal
	}
	private canvas_quest4_Internal: mw.Canvas
	public get canvas_quest4(): mw.Canvas {
		if(!this.canvas_quest4_Internal&&this.uiWidgetBase) {
			this.canvas_quest4_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest4') as mw.Canvas
		}
		return this.canvas_quest4_Internal
	}
	private img_quest4_bg_Internal: mw.Image
	public get img_quest4_bg(): mw.Image {
		if(!this.img_quest4_bg_Internal&&this.uiWidgetBase) {
			this.img_quest4_bg_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest4/img_quest4_bg') as mw.Image
		}
		return this.img_quest4_bg_Internal
	}
	private btn_quest4_Internal: mw.Button
	public get btn_quest4(): mw.Button {
		if(!this.btn_quest4_Internal&&this.uiWidgetBase) {
			this.btn_quest4_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest4/btn_quest4') as mw.Button
		}
		return this.btn_quest4_Internal
	}
	private img_prices4_Internal: mw.Image
	public get img_prices4(): mw.Image {
		if(!this.img_prices4_Internal&&this.uiWidgetBase) {
			this.img_prices4_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest4/btn_quest4/img_prices4') as mw.Image
		}
		return this.img_prices4_Internal
	}
	private txt_prices4_Internal: mw.TextBlock
	public get txt_prices4(): mw.TextBlock {
		if(!this.txt_prices4_Internal&&this.uiWidgetBase) {
			this.txt_prices4_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest4/btn_quest4/txt_prices4') as mw.TextBlock
		}
		return this.txt_prices4_Internal
	}
	private img_quest4_icon_Internal: mw.Image
	public get img_quest4_icon(): mw.Image {
		if(!this.img_quest4_icon_Internal&&this.uiWidgetBase) {
			this.img_quest4_icon_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest4/img_quest4_icon') as mw.Image
		}
		return this.img_quest4_icon_Internal
	}
	private txt_quest4_Internal: mw.TextBlock
	public get txt_quest4(): mw.TextBlock {
		if(!this.txt_quest4_Internal&&this.uiWidgetBase) {
			this.txt_quest4_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest4/txt_quest4') as mw.TextBlock
		}
		return this.txt_quest4_Internal
	}
	private canvas_quest5_Internal: mw.Canvas
	public get canvas_quest5(): mw.Canvas {
		if(!this.canvas_quest5_Internal&&this.uiWidgetBase) {
			this.canvas_quest5_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest5') as mw.Canvas
		}
		return this.canvas_quest5_Internal
	}
	private img_quest5_bg_Internal: mw.Image
	public get img_quest5_bg(): mw.Image {
		if(!this.img_quest5_bg_Internal&&this.uiWidgetBase) {
			this.img_quest5_bg_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest5/img_quest5_bg') as mw.Image
		}
		return this.img_quest5_bg_Internal
	}
	private btn_quest5_Internal: mw.Button
	public get btn_quest5(): mw.Button {
		if(!this.btn_quest5_Internal&&this.uiWidgetBase) {
			this.btn_quest5_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest5/btn_quest5') as mw.Button
		}
		return this.btn_quest5_Internal
	}
	private img_prices5_Internal: mw.Image
	public get img_prices5(): mw.Image {
		if(!this.img_prices5_Internal&&this.uiWidgetBase) {
			this.img_prices5_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest5/btn_quest5/img_prices5') as mw.Image
		}
		return this.img_prices5_Internal
	}
	private txt_prices5_Internal: mw.TextBlock
	public get txt_prices5(): mw.TextBlock {
		if(!this.txt_prices5_Internal&&this.uiWidgetBase) {
			this.txt_prices5_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest5/btn_quest5/txt_prices5') as mw.TextBlock
		}
		return this.txt_prices5_Internal
	}
	private img_quest5_icon_Internal: mw.Image
	public get img_quest5_icon(): mw.Image {
		if(!this.img_quest5_icon_Internal&&this.uiWidgetBase) {
			this.img_quest5_icon_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest5/img_quest5_icon') as mw.Image
		}
		return this.img_quest5_icon_Internal
	}
	private txt_quest5_Internal: mw.TextBlock
	public get txt_quest5(): mw.TextBlock {
		if(!this.txt_quest5_Internal&&this.uiWidgetBase) {
			this.txt_quest5_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest5/txt_quest5') as mw.TextBlock
		}
		return this.txt_quest5_Internal
	}
	private canvas_quest6_Internal: mw.Canvas
	public get canvas_quest6(): mw.Canvas {
		if(!this.canvas_quest6_Internal&&this.uiWidgetBase) {
			this.canvas_quest6_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest6') as mw.Canvas
		}
		return this.canvas_quest6_Internal
	}
	private img_quest6_bg_Internal: mw.Image
	public get img_quest6_bg(): mw.Image {
		if(!this.img_quest6_bg_Internal&&this.uiWidgetBase) {
			this.img_quest6_bg_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest6/img_quest6_bg') as mw.Image
		}
		return this.img_quest6_bg_Internal
	}
	private btn_quest6_Internal: mw.Button
	public get btn_quest6(): mw.Button {
		if(!this.btn_quest6_Internal&&this.uiWidgetBase) {
			this.btn_quest6_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest6/btn_quest6') as mw.Button
		}
		return this.btn_quest6_Internal
	}
	private img_prices6_Internal: mw.Image
	public get img_prices6(): mw.Image {
		if(!this.img_prices6_Internal&&this.uiWidgetBase) {
			this.img_prices6_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest6/btn_quest6/img_prices6') as mw.Image
		}
		return this.img_prices6_Internal
	}
	private txt_prices6_Internal: mw.TextBlock
	public get txt_prices6(): mw.TextBlock {
		if(!this.txt_prices6_Internal&&this.uiWidgetBase) {
			this.txt_prices6_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest6/btn_quest6/txt_prices6') as mw.TextBlock
		}
		return this.txt_prices6_Internal
	}
	private img_quest6_icon_Internal: mw.Image
	public get img_quest6_icon(): mw.Image {
		if(!this.img_quest6_icon_Internal&&this.uiWidgetBase) {
			this.img_quest6_icon_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest6/img_quest6_icon') as mw.Image
		}
		return this.img_quest6_icon_Internal
	}
	private txt_quest6_Internal: mw.TextBlock
	public get txt_quest6(): mw.TextBlock {
		if(!this.txt_quest6_Internal&&this.uiWidgetBase) {
			this.txt_quest6_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_premium/canvas_quest_premium/canvas_quest6/txt_quest6') as mw.TextBlock
		}
		return this.txt_quest6_Internal
	}
	private canvas_times_premium_Internal: mw.Canvas
	public get canvas_times_premium(): mw.Canvas {
		if(!this.canvas_times_premium_Internal&&this.uiWidgetBase) {
			this.canvas_times_premium_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_times_premium') as mw.Canvas
		}
		return this.canvas_times_premium_Internal
	}
	private img_bg2_Internal: mw.Image
	public get img_bg2(): mw.Image {
		if(!this.img_bg2_Internal&&this.uiWidgetBase) {
			this.img_bg2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_times_premium/img_bg2') as mw.Image
		}
		return this.img_bg2_Internal
	}
	private txt_times_premium_Internal: mw.TextBlock
	public get txt_times_premium(): mw.TextBlock {
		if(!this.txt_times_premium_Internal&&this.uiWidgetBase) {
			this.txt_times_premium_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_times_premium/txt_times_premium') as mw.TextBlock
		}
		return this.txt_times_premium_Internal
	}
	private img_icon22_Internal: mw.Image
	public get img_icon22(): mw.Image {
		if(!this.img_icon22_Internal&&this.uiWidgetBase) {
			this.img_icon22_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_times_premium/img_icon22') as mw.Image
		}
		return this.img_icon22_Internal
	}
	private canvas_preview_premium_Internal: mw.Canvas
	public get canvas_preview_premium(): mw.Canvas {
		if(!this.canvas_preview_premium_Internal&&this.uiWidgetBase) {
			this.canvas_preview_premium_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_preview_premium') as mw.Canvas
		}
		return this.canvas_preview_premium_Internal
	}
	private img_preview_bg4_Internal: mw.Image
	public get img_preview_bg4(): mw.Image {
		if(!this.img_preview_bg4_Internal&&this.uiWidgetBase) {
			this.img_preview_bg4_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_preview_premium/img_preview_bg4') as mw.Image
		}
		return this.img_preview_bg4_Internal
	}
	private btn_preview2_Internal: mw.Button
	public get btn_preview2(): mw.Button {
		if(!this.btn_preview2_Internal&&this.uiWidgetBase) {
			this.btn_preview2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_preview_premium/btn_preview2') as mw.Button
		}
		return this.btn_preview2_Internal
	}
	private txt_preview2_Internal: mw.TextBlock
	public get txt_preview2(): mw.TextBlock {
		if(!this.txt_preview2_Internal&&this.uiWidgetBase) {
			this.txt_preview2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_preview_premium/txt_preview2') as mw.TextBlock
		}
		return this.txt_preview2_Internal
	}
	private canvas_lottery_premium_Internal: mw.Canvas
	public get canvas_lottery_premium(): mw.Canvas {
		if(!this.canvas_lottery_premium_Internal&&this.uiWidgetBase) {
			this.canvas_lottery_premium_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_lottery_premium') as mw.Canvas
		}
		return this.canvas_lottery_premium_Internal
	}
	private btn_premium1_Internal: mw.Button
	public get btn_premium1(): mw.Button {
		if(!this.btn_premium1_Internal&&this.uiWidgetBase) {
			this.btn_premium1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_lottery_premium/btn_premium1') as mw.Button
		}
		return this.btn_premium1_Internal
	}
	private txt_premium1_Internal: mw.TextBlock
	public get txt_premium1(): mw.TextBlock {
		if(!this.txt_premium1_Internal&&this.uiWidgetBase) {
			this.txt_premium1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_lottery_premium/btn_premium1/txt_premium1') as mw.TextBlock
		}
		return this.txt_premium1_Internal
	}
	private btn_premium10_Internal: mw.Button
	public get btn_premium10(): mw.Button {
		if(!this.btn_premium10_Internal&&this.uiWidgetBase) {
			this.btn_premium10_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_lottery_premium/btn_premium10') as mw.Button
		}
		return this.btn_premium10_Internal
	}
	private txt_premium10_Internal: mw.TextBlock
	public get txt_premium10(): mw.TextBlock {
		if(!this.txt_premium10_Internal&&this.uiWidgetBase) {
			this.txt_premium10_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_lottery_premium/btn_premium10/txt_premium10') as mw.TextBlock
		}
		return this.txt_premium10_Internal
	}
	private canvas_type_Internal: mw.Canvas
	public get canvas_type(): mw.Canvas {
		if(!this.canvas_type_Internal&&this.uiWidgetBase) {
			this.canvas_type_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_type') as mw.Canvas
		}
		return this.canvas_type_Internal
	}
	private canvas_type_normal_Internal: mw.Canvas
	public get canvas_type_normal(): mw.Canvas {
		if(!this.canvas_type_normal_Internal&&this.uiWidgetBase) {
			this.canvas_type_normal_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_type/canvas_type_normal') as mw.Canvas
		}
		return this.canvas_type_normal_Internal
	}
	private btn_normal_Internal: mw.Button
	public get btn_normal(): mw.Button {
		if(!this.btn_normal_Internal&&this.uiWidgetBase) {
			this.btn_normal_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_type/canvas_type_normal/btn_normal') as mw.Button
		}
		return this.btn_normal_Internal
	}
	private img_normal_bg_Internal: mw.Image
	public get img_normal_bg(): mw.Image {
		if(!this.img_normal_bg_Internal&&this.uiWidgetBase) {
			this.img_normal_bg_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_type/canvas_type_normal/img_normal_bg') as mw.Image
		}
		return this.img_normal_bg_Internal
	}
	private img_normal_name_Internal: mw.Image
	public get img_normal_name(): mw.Image {
		if(!this.img_normal_name_Internal&&this.uiWidgetBase) {
			this.img_normal_name_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_type/canvas_type_normal/img_normal_name') as mw.Image
		}
		return this.img_normal_name_Internal
	}
	private img_selected_normal_Internal: mw.Image
	public get img_selected_normal(): mw.Image {
		if(!this.img_selected_normal_Internal&&this.uiWidgetBase) {
			this.img_selected_normal_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_type/canvas_type_normal/img_selected_normal') as mw.Image
		}
		return this.img_selected_normal_Internal
	}
	private canvas_type_premium_Internal: mw.Canvas
	public get canvas_type_premium(): mw.Canvas {
		if(!this.canvas_type_premium_Internal&&this.uiWidgetBase) {
			this.canvas_type_premium_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_type/canvas_type_premium') as mw.Canvas
		}
		return this.canvas_type_premium_Internal
	}
	private btn_premium_Internal: mw.Button
	public get btn_premium(): mw.Button {
		if(!this.btn_premium_Internal&&this.uiWidgetBase) {
			this.btn_premium_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_type/canvas_type_premium/btn_premium') as mw.Button
		}
		return this.btn_premium_Internal
	}
	private img_selected_special_Internal: mw.Image
	public get img_selected_special(): mw.Image {
		if(!this.img_selected_special_Internal&&this.uiWidgetBase) {
			this.img_selected_special_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_type/canvas_type_premium/img_selected_special') as mw.Image
		}
		return this.img_selected_special_Internal
	}
	private img_premium_bg_Internal: mw.Image
	public get img_premium_bg(): mw.Image {
		if(!this.img_premium_bg_Internal&&this.uiWidgetBase) {
			this.img_premium_bg_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_type/canvas_type_premium/img_premium_bg') as mw.Image
		}
		return this.img_premium_bg_Internal
	}
	private img_premium_name_Internal: mw.Image
	public get img_premium_name(): mw.Image {
		if(!this.img_premium_name_Internal&&this.uiWidgetBase) {
			this.img_premium_name_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_type/canvas_type_premium/img_premium_name') as mw.Image
		}
		return this.img_premium_name_Internal
	}
	private canvas_close_Internal: mw.Canvas
	public get canvas_close(): mw.Canvas {
		if(!this.canvas_close_Internal&&this.uiWidgetBase) {
			this.canvas_close_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_close') as mw.Canvas
		}
		return this.canvas_close_Internal
	}
	private con_reward_preview_Internal: mw.Canvas
	public get con_reward_preview(): mw.Canvas {
		if(!this.con_reward_preview_Internal&&this.uiWidgetBase) {
			this.con_reward_preview_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_close/con_reward_preview') as mw.Canvas
		}
		return this.con_reward_preview_Internal
	}
	private con_reward_preview_items_Internal: mw.Canvas
	public get con_reward_preview_items(): mw.Canvas {
		if(!this.con_reward_preview_items_Internal&&this.uiWidgetBase) {
			this.con_reward_preview_items_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_close/con_reward_preview/ScrollBox/con_reward_preview_items') as mw.Canvas
		}
		return this.con_reward_preview_items_Internal
	}
	private btn_close_Internal: mw.Button
	public get btn_close(): mw.Button {
		if(!this.btn_close_Internal&&this.uiWidgetBase) {
			this.btn_close_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/canvas_close/btn_close') as mw.Button
		}
		return this.btn_close_Internal
	}



	public showAction: mw.Action1<mw.UIScript> = new mw.Action1<mw.UIScript>();
	public hideAction: mw.Action1<mw.UIScript> = new mw.Action1<mw.UIScript>();
 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = mw.UILayerBottom;
		this.initButtons();
	}

	protected initButtons() {
		//按钮添加点击
		
		this.mBtn_20Times.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mBtn_20Times");
		})
		this.initLanguage(this.mBtn_20Times);
		
	
		this.mBtn_40Times.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mBtn_40Times");
		})
		this.initLanguage(this.mBtn_40Times);
		
	
		this.mBtn_60Times.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mBtn_60Times");
		})
		this.initLanguage(this.mBtn_60Times);
		
	
		this.mBtn_100Times.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mBtn_100Times");
		})
		this.initLanguage(this.mBtn_100Times);
		
	
		this.mBtn_Get.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mBtn_Get");
		})
		this.initLanguage(this.mBtn_Get);
		
	
		//按钮添加点击
		
		this.btn_quest1.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "btn_quest1");
		})
		
	
		this.btn_quest2.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "btn_quest2");
		})
		
	
		this.btn_quest3.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "btn_quest3");
		})
		
	
		this.mBtn_Open.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mBtn_Open");
		})
		
	
		this.btn_quest4.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "btn_quest4");
		})
		
	
		this.btn_quest5.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "btn_quest5");
		})
		
	
		this.btn_quest6.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "btn_quest6");
		})
		
	
		this.btn_preview2.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "btn_preview2");
		})
		
	
		this.btn_premium1.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "btn_premium1");
		})
		
	
		this.btn_premium10.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "btn_premium10");
		})
		
	
		this.btn_normal.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "btn_normal");
		})
		
	
		this.btn_premium.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "btn_premium");
		})
		
	
		this.btn_close.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "btn_close");
		})
		
	

		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.txt_prices1)
		
	
		this.initLanguage(this.txt_quest1)
		
	
		this.initLanguage(this.txt_prices2)
		
	
		this.initLanguage(this.txt_quest2)
		
	
		this.initLanguage(this.txt_prices3)
		
	
		this.initLanguage(this.txt_quest3)
		
	
		this.initLanguage(this.mTxt_GachaTimes)
		
	
		this.initLanguage(this.txt_prices4)
		
	
		this.initLanguage(this.txt_quest4)
		
	
		this.initLanguage(this.txt_prices5)
		
	
		this.initLanguage(this.txt_quest5)
		
	
		this.initLanguage(this.txt_prices6)
		
	
		this.initLanguage(this.txt_quest6)
		
	
		this.initLanguage(this.txt_times_premium)
		
	
		this.initLanguage(this.txt_preview2)
		
	
		this.initLanguage(this.txt_premium1)
		
	
		this.initLanguage(this.txt_premium10)
		
	
		//文本多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/canvas_normal/mCanvas_Goods/TextBlock_5") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas_reward/Canvas_1/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas_reward/Canvas_1_1/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas_reward/Canvas_1_1_1/TextBlock_2") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas_reward/Canvas_1_1_1_1/TextBlock_3") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas_reward/TextBlock_4") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas_reward/TextBlock_4_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas_reward/TextBlock_4_2") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas_reward/TextBlock_4_3") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/canvas_Gifts/canvas_GiftsItem/TextBlock_6") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/canvas_Gifts/canvas_GiftsItem/Canvas/TextBlock_7") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/canvas_Gifts/canvas_GiftsItem/Canvas/TextBlock_8") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/canvas_Gifts/canvas_GiftsItem/Canvas/TextBlock_9") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/canvas_Gifts/canvas_GiftsItem/Canvas/TextBlock_10") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/canvas_Gifts/canvas_GiftsItem/Canvas_1/TextBlock_7") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/canvas_Gifts/canvas_GiftsItem/Canvas_1/TextBlock_8") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/canvas_Gifts/canvas_GiftsItem/Canvas_1/TextBlock_9") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/canvas_Gifts/canvas_GiftsItem/Canvas_1/TextBlock_10_1") as any);
		
	

	}
	private initLanguage(ui: mw.StaleButton | mw.TextBlock) {
        let call = mw.UIScript.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }

	protected onShow(...params: any[]): void {};

    public show(...param): void {
		Event.dispatchToLocal("ShowUIAction_37", this);
		this.showAction.call(this);
		mw.UIService.showUI(this, this.layer, ...param);
	}

    public hide(): void {
		Event.dispatchToLocal("HideUIAction_37", this);
		this.hideAction.call(this);
		mw.UIService.hideUI(this);
	}
}
 