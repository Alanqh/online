﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 */



@UIBind('UI/Shop/Hot.ui')
export default class Hot_Generate extends UIScript {
		private mBtn_Buy_Internal: mw.StaleButton
	public get mBtn_Buy(): mw.StaleButton {
		if(!this.mBtn_Buy_Internal&&this.uiWidgetBase) {
			this.mBtn_Buy_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mBtn_Buy') as mw.StaleButton
		}
		return this.mBtn_Buy_Internal
	}
	private mCanvas_DayOne_Internal: mw.Canvas
	public get mCanvas_DayOne(): mw.Canvas {
		if(!this.mCanvas_DayOne_Internal&&this.uiWidgetBase) {
			this.mCanvas_DayOne_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mCanvas_DayOne') as mw.Canvas
		}
		return this.mCanvas_DayOne_Internal
	}
	private mCanvas_DayOne2_Internal: mw.Canvas
	public get mCanvas_DayOne2(): mw.Canvas {
		if(!this.mCanvas_DayOne2_Internal&&this.uiWidgetBase) {
			this.mCanvas_DayOne2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mCanvas_DayOne/mCanvas_DayOne2') as mw.Canvas
		}
		return this.mCanvas_DayOne2_Internal
	}
	private mCanvas_DayOne1_Internal: mw.Canvas
	public get mCanvas_DayOne1(): mw.Canvas {
		if(!this.mCanvas_DayOne1_Internal&&this.uiWidgetBase) {
			this.mCanvas_DayOne1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mCanvas_DayOne/mCanvas_DayOne1') as mw.Canvas
		}
		return this.mCanvas_DayOne1_Internal
	}
	private mCanvas_DayOne3_Internal: mw.Canvas
	public get mCanvas_DayOne3(): mw.Canvas {
		if(!this.mCanvas_DayOne3_Internal&&this.uiWidgetBase) {
			this.mCanvas_DayOne3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mCanvas_DayOne/mCanvas_DayOne3') as mw.Canvas
		}
		return this.mCanvas_DayOne3_Internal
	}
	private mCanvas_DayTwo_Internal: mw.Canvas
	public get mCanvas_DayTwo(): mw.Canvas {
		if(!this.mCanvas_DayTwo_Internal&&this.uiWidgetBase) {
			this.mCanvas_DayTwo_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mCanvas_DayTwo') as mw.Canvas
		}
		return this.mCanvas_DayTwo_Internal
	}
	private mCanvas_DayTwo1_Internal: mw.Canvas
	public get mCanvas_DayTwo1(): mw.Canvas {
		if(!this.mCanvas_DayTwo1_Internal&&this.uiWidgetBase) {
			this.mCanvas_DayTwo1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mCanvas_DayTwo/mCanvas_DayTwo1') as mw.Canvas
		}
		return this.mCanvas_DayTwo1_Internal
	}
	private mCanvas_DayTwo2_Internal: mw.Canvas
	public get mCanvas_DayTwo2(): mw.Canvas {
		if(!this.mCanvas_DayTwo2_Internal&&this.uiWidgetBase) {
			this.mCanvas_DayTwo2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mCanvas_DayTwo/mCanvas_DayTwo2') as mw.Canvas
		}
		return this.mCanvas_DayTwo2_Internal
	}
	private mCanvas_DayTwo3_Internal: mw.Canvas
	public get mCanvas_DayTwo3(): mw.Canvas {
		if(!this.mCanvas_DayTwo3_Internal&&this.uiWidgetBase) {
			this.mCanvas_DayTwo3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mCanvas_DayTwo/mCanvas_DayTwo3') as mw.Canvas
		}
		return this.mCanvas_DayTwo3_Internal
	}
	private mCanvas_DayThree_Internal: mw.Canvas
	public get mCanvas_DayThree(): mw.Canvas {
		if(!this.mCanvas_DayThree_Internal&&this.uiWidgetBase) {
			this.mCanvas_DayThree_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mCanvas_DayThree') as mw.Canvas
		}
		return this.mCanvas_DayThree_Internal
	}
	private mCanvas_DayThree1_Internal: mw.Canvas
	public get mCanvas_DayThree1(): mw.Canvas {
		if(!this.mCanvas_DayThree1_Internal&&this.uiWidgetBase) {
			this.mCanvas_DayThree1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mCanvas_DayThree/mCanvas_DayThree1') as mw.Canvas
		}
		return this.mCanvas_DayThree1_Internal
	}
	private mCanvas_DayThree2_Internal: mw.Canvas
	public get mCanvas_DayThree2(): mw.Canvas {
		if(!this.mCanvas_DayThree2_Internal&&this.uiWidgetBase) {
			this.mCanvas_DayThree2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mCanvas_DayThree/mCanvas_DayThree2') as mw.Canvas
		}
		return this.mCanvas_DayThree2_Internal
	}
	private mCanvas_DayThree3_Internal: mw.Canvas
	public get mCanvas_DayThree3(): mw.Canvas {
		if(!this.mCanvas_DayThree3_Internal&&this.uiWidgetBase) {
			this.mCanvas_DayThree3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mCanvas_DayThree/mCanvas_DayThree3') as mw.Canvas
		}
		return this.mCanvas_DayThree3_Internal
	}
	private mImage_Dark1_Internal: mw.Image
	public get mImage_Dark1(): mw.Image {
		if(!this.mImage_Dark1_Internal&&this.uiWidgetBase) {
			this.mImage_Dark1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mImage_Dark1') as mw.Image
		}
		return this.mImage_Dark1_Internal
	}
	private mImage_Dark3_Internal: mw.Image
	public get mImage_Dark3(): mw.Image {
		if(!this.mImage_Dark3_Internal&&this.uiWidgetBase) {
			this.mImage_Dark3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mImage_Dark3') as mw.Image
		}
		return this.mImage_Dark3_Internal
	}
	private mImage_Dark2_Internal: mw.Image
	public get mImage_Dark2(): mw.Image {
		if(!this.mImage_Dark2_Internal&&this.uiWidgetBase) {
			this.mImage_Dark2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mImage_Dark2') as mw.Image
		}
		return this.mImage_Dark2_Internal
	}
	private mText_Get_2_Internal: mw.TextBlock
	public get mText_Get_2(): mw.TextBlock {
		if(!this.mText_Get_2_Internal&&this.uiWidgetBase) {
			this.mText_Get_2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mText_Get_2') as mw.TextBlock
		}
		return this.mText_Get_2_Internal
	}
	private mText_Get_1_Internal: mw.TextBlock
	public get mText_Get_1(): mw.TextBlock {
		if(!this.mText_Get_1_Internal&&this.uiWidgetBase) {
			this.mText_Get_1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mText_Get_1') as mw.TextBlock
		}
		return this.mText_Get_1_Internal
	}
	private mText_Get_3_Internal: mw.TextBlock
	public get mText_Get_3(): mw.TextBlock {
		if(!this.mText_Get_3_Internal&&this.uiWidgetBase) {
			this.mText_Get_3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mText_Get_3') as mw.TextBlock
		}
		return this.mText_Get_3_Internal
	}
	private mTxt_State_Internal: mw.TextBlock
	public get mTxt_State(): mw.TextBlock {
		if(!this.mTxt_State_Internal&&this.uiWidgetBase) {
			this.mTxt_State_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mTxt_State') as mw.TextBlock
		}
		return this.mTxt_State_Internal
	}
	private mImg_Buy_Internal: mw.Image
	public get mImg_Buy(): mw.Image {
		if(!this.mImg_Buy_Internal&&this.uiWidgetBase) {
			this.mImg_Buy_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Canvas/mImg_Buy') as mw.Image
		}
		return this.mImg_Buy_Internal
	}



	public showAction: mw.Action1<mw.UIScript> = new mw.Action1<mw.UIScript>();
	public hideAction: mw.Action1<mw.UIScript> = new mw.Action1<mw.UIScript>();
 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = mw.UILayerBottom;
		this.initButtons();
	}

	protected initButtons() {
		//按钮添加点击
		
		this.mBtn_Buy.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mBtn_Buy");
		})
		this.initLanguage(this.mBtn_Buy);
		
	
		//按钮添加点击
		

		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mText_Get_2)
		
	
		this.initLanguage(this.mText_Get_1)
		
	
		this.initLanguage(this.mText_Get_3)
		
	
		this.initLanguage(this.mTxt_State)
		
	
		//文本多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/TextBlock") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/TextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/TextBlock_2") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/TextBlock_3") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/TextBlock_4") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/TextBlock_5") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/TextBlock_6") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/TextBlock_6_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/TextBlock_6_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/TextBlock_7") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/mCanvas_DayTwo/TextBlock_8_1_2") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/mCanvas_DayTwo/TextBlock_8_1_2_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/mCanvas_DayTwo/TextBlock_8_1_2_2") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/mCanvas_DayThree/TextBlock_8_1_2_3") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/mCanvas_DayThree/TextBlock_8_1_2_2_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/mCanvas_DayThree/TextBlock_8_1_2_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/TextBlock_8") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/TextBlock_8_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/TextBlock_8_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/TextBlock_8_1_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/mImg_Buy/TextBlock_3") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("RootCanvas/Canvas/mImg_Buy/TextBlock_4") as any);
		
	

	}
	private initLanguage(ui: mw.StaleButton | mw.TextBlock) {
        let call = mw.UIScript.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }

	protected onShow(...params: any[]): void {};

    public show(...param): void {
		Event.dispatchToLocal("ShowUIAction_37", this);
		this.showAction.call(this);
		mw.UIService.showUI(this, this.layer, ...param);
	}

    public hide(): void {
		Event.dispatchToLocal("HideUIAction_37", this);
		this.hideAction.call(this);
		mw.UIService.hideUI(this);
	}
}
 