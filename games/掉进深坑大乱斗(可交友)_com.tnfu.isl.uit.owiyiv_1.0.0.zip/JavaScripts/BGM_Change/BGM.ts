﻿// @Component
// export default class MusicManager extends mw.Script {

//     protected onStart(): void {
//         let isBGMPlaying: boolean = true;
//         if(SystemUtil.isServer()){
//             if(isBGMPlaying){
//                 this.playGlobalBGM();
//             }
//         }
//     }

//     private playGlobalBGM(): void {
//         const bgmSoundAssetId = "129959";
//         SoundService.play3DSound("129959");
//     }
    
// }
