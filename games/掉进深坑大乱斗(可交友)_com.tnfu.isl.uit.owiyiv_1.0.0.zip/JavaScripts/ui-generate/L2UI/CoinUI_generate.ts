﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * ATTENTION: onStart 等UI脚本自带函数不可改写为异步执行，有需求的异步逻辑请使用函数封装，通过函数接口在内部使用
 * UI: UI/L2UI/CoinUI.ui
*/



@UIBind('UI/L2UI/CoinUI.ui')
export default class CoinUI_Generate extends UIScript {
		private coinCount_Internal: mw.TextBlock
	public get coinCount(): mw.TextBlock {
		if(!this.coinCount_Internal&&this.uiWidgetBase) {
			this.coinCount_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/Image/coinCount') as mw.TextBlock
		}
		return this.coinCount_Internal
	}


 
	/**
	* onStart 之前触发一次
	*/
	protected onAwake() {
	}
	 
}
 