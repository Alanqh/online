﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 一纸红笺
 * UI: UI/DefaultUI.ui
 * TIME: 2023.09.06-10.43.04
*/



@UIBind('UI/DefaultUI.ui')
export default class DefaultUI_Generate extends mw.UIScript {
	

 
	/**
	* onStart 之前触发一次
	*/
	protected onAwake() {
	}
	 
}
 