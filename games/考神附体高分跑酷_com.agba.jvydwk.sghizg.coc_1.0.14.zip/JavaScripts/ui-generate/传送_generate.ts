﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 一纸红笺
 * UI: UI/传送.ui
 * TIME: 2023.09.06-10.43.04
*/



@UIBind('UI/传送.ui')
export default class 传送_Generate extends mw.UIScript {
	

 
	/**
	* onStart 之前触发一次
	*/
	protected onAwake() {
	}
	 
}
 