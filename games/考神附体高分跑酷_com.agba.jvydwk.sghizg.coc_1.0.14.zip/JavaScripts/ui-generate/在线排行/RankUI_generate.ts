﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 一纸红笺
 * UI: UI/在线排行/RankUI.ui
 * TIME: 2023.09.06-10.43.04
*/



@UIBind('UI/在线排行/RankUI.ui')
export default class RankUI_Generate extends mw.UIScript {
	@UIWidgetBind('RootCanvas/Canvas/mtbtn')
    public mtbtn: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/Canvas/mScrollBox')
    public mScrollBox: mw.ScrollBox=undefined;
    

 
	/**
	* onStart 之前触发一次
	*/
	protected onAwake() {
	}
	 
}
 