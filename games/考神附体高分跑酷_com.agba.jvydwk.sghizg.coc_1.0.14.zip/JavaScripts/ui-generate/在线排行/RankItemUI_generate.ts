﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 一纸红笺
 * UI: UI/在线排行/RankItemUI.ui
 * TIME: 2023.09.06-10.43.04
*/



@UIBind('UI/在线排行/RankItemUI.ui')
export default class RankItemUI_Generate extends mw.UIScript {
	@UIWidgetBind('RootCanvas/mRank_txt')
    public mRank_txt: mw.TextBlock=undefined;
    

 
	/**
	* onStart 之前触发一次
	*/
	protected onAwake() {
	}
	 
}
 