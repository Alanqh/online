﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 一纸红笺
 * UI: UI/MainUI.ui
 * TIME: 2023.09.06-10.43.04
*/



@UIBind('UI/MainUI.ui')
export default class MainUI_Generate extends mw.UIScript {
	@UIWidgetBind('RootCanvas/Top/protxt')
    public protxt: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/Top/pro')
    public pro: mw.Image=undefined;
    @UIWidgetBind('RootCanvas/Top/flytxt')
    public flytxt: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/Online/olbtxt')
    public olbtxt: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/Online/olbtn')
    public olbtn: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/Show/Move_3/skip')
    public skip: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/Show/Move_3_1/fly')
    public fly: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/Show/Move_3_2/addspeed')
    public addspeed: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/Show/Move_3_3/addjump')
    public addjump: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/Show/Move_3_3_1/cuptxt')
    public cuptxt: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/test')
    public test: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/test/b1')
    public b1: mw.StaleButton=undefined;
    @UIWidgetBind('RootCanvas/test/b2')
    public b2: mw.StaleButton=undefined;
    @UIWidgetBind('RootCanvas/test/b3')
    public b3: mw.StaleButton=undefined;
    @UIWidgetBind('RootCanvas/test/b4')
    public b4: mw.StaleButton=undefined;
    @UIWidgetBind('RootCanvas/test/b5')
    public b5: mw.StaleButton=undefined;
    @UIWidgetBind('RootCanvas/test/in1')
    public in1: mw.InputBox=undefined;
    @UIWidgetBind('RootCanvas/test/b6')
    public b6: mw.StaleButton=undefined;
    @UIWidgetBind('RootCanvas/idtxt')
    public idtxt: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/Down/Move_3/dress')
    public dress: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/Down/Move_3_1/tail')
    public tail: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/Down/Move_3_2/wing')
    public wing: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/Down/Move_3_2_1_1/ava')
    public ava: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/Right/Move_3/home')
    public home: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/dressp')
    public dressp: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/dressp/dressclose')
    public dressclose: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/dressp/ScrollBox/dressc')
    public dressc: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/tailp')
    public tailp: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/tailp/tailclose')
    public tailclose: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/tailp/ScrollBox/tailc')
    public tailc: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/wingp')
    public wingp: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/wingp/wingclose')
    public wingclose: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/wingp/ScrollBox/wingc')
    public wingc: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/avap')
    public avap: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/avap/avaclose')
    public avaclose: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/avap/ScrollBox/avac')
    public avac: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/fudong')
    public fudong: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/fudong/fdimg')
    public fdimg: mw.Image=undefined;
    @UIWidgetBind('RootCanvas/fudong/fdtxt')
    public fdtxt: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/tips')
    public tips: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/tips/tiptxt')
    public tiptxt: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/tips/tipclose')
    public tipclose: mw.Button=undefined;
    @UIWidgetBind('RootCanvas/tips/tipok')
    public tipok: mw.StaleButton=undefined;
    

 
	/**
	* onStart 之前触发一次
	*/
	protected onAwake() {
	}
	 
}
 