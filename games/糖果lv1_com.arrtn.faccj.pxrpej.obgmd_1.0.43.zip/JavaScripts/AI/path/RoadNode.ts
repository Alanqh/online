/** 
 * @Author       : lei.zhao
 * @Date         : 2023-01-31 17:27:57
 * @LastEditors  : lei.zhao
 * @LastEditTime : 2023-01-31 17:28:04
 * @FilePath     : \stumbleguys\JavaScripts\AI\road\RoadNode.ts
 * @Description  : 修改描述
 */
export class RoadNode {
    constructor(public id: number, public location: Vector, public flag: number) {

    }

}