﻿/** 
 * @Author       : yuanqi.bai
 * @Date         : 2023-06-06 11:08:19
 * @LastEditors  : yuanqi.bai
 * @LastEditTime : 2023-06-06 11:28:38
 * @FilePath     : \stumbleguys\JavaScripts\Prefabs\旋转栅栏\Script\TangentialScript.ts
 * @Description  : 修改描述
 */
import TangentialScriptBase from "../../../newPrefab/TangentialScript";

@Component
export default class TangentialScript extends TangentialScriptBase {

}